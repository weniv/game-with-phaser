import Config from "./Config";

const game = new Phaser.Game(Config);

export default game;
